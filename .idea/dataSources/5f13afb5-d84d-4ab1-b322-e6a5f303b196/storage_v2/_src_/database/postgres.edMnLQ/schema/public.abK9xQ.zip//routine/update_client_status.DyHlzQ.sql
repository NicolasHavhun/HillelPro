create function update_client_status() returns trigger
    language plpgsql
as
$$
DECLARE
	curs CURSOR FOR SELECT * FROM client_status;
    clcl_id int;
    clst_id int;
BEGIN

    IF    TG_OP = 'INSERT' THEN
		FOR row IN curs LOOP

        clcl_id = NEW.id;
		clst_id = (SELECT id FROM statuses WHERE alias = 'STANDARD');
        INSERT INTO client_status(client_id,status_id) VALUES (clcl_id, clst_id);
        RETURN NEW;
		END LOOP;
		
		ELSIF    TG_OP = 'UPDATE' THEN
		FOR row IN curs LOOP

        clcl_id = NEW.id;
		clst_id = (SELECT id FROM statuses WHERE alias = 'STANDARD');
        INSERT INTO client_status(client_id,status_id) VALUES (clcl_id, clst_id);
        RETURN NEW;
		END LOOP;
		
    ELSIF TG_OP = 'DELETE' THEN
	FOR row IN curs LOOP
        clcl_id = OLD.id;
        DELETE FROM client_status WHERE client_id = clcl_id;
        RETURN OLD;
		END LOOP;
    END IF;
END;
$$;

alter function update_client_status() owner to postgres;

